package pizzapatterns;

public interface Base {
    String getSize();
    double getPrice();
}
