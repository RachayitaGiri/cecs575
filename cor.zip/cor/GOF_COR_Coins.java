package cor;

public class GOF_COR_Coins {
    static AppClass app;
    //see next page
    public static void main(String[] args) {
        app = new AppClass();
        app.run();
    }
}
