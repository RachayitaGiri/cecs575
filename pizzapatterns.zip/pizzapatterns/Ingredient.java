package pizzapatterns;

public interface Ingredient {
    String getName();
    double getPrice();
}
